#include <cstdlib>
#include <iostream>
#include<iomanip>
#include<cmath>

using namespace std;

//Write a C++ program (using function overloaded) to sort 10 integer values.

void mysort(int vallist[]){

    int i,j;
    int temp;
      for(i=0;i<10;i++)
     for(j=0;j<10;j++)
      if(vallist[j]>vallist[j+1]){
         temp=vallist[j];
         vallist[j]=vallist[j+1];
         vallist[j+1]=temp;
       }

       for(i=0;i<10;i++)cout<<vallist[i]<<"\n";

}

void mysort(float vallist[]){

    int i,j;
    float temp;
      for(i=0;i<10;i++)
     for(j=0;j<10;j++)
      if(vallist[j]>vallist[j+1]){
         temp=vallist[j];
         vallist[j]=vallist[j+1];
         vallist[j+1]=temp;
       }

       for(i=0;i<10;i++)cout<<vallist[i]<<"\n";

}
void mysort(double vallist[]){

    int i,j;
    double temp;
      for(i=0;i<10;i++)
     for(j=0;j<10;j++)
      if(vallist[j]>vallist[j+1]){
         temp=vallist[j];
         vallist[j]=vallist[j+1];
         vallist[j+1]=temp;
       }

       for(i=0;i<10;i++)cout<<vallist[i]<<"\n";

}

int main(int argc, char *argv[])
{
  int vallist[]={21,2,34,21,43,22,32,32,43,34};
  mysort(vallist);
  system("PAUSE");
  return EXIT_SUCCESS;
}
