
#include <cstdlib>
#include <iostream>

using namespace std;

//  A program to prompt the user to input ten integer values

int main(int argc, char *argv[])
{
    int arr[10]; int mode[10][2];

   cout<<"Enter 10 integer values\n";

  for(int i=0;i<10;i++) {
     cout<<"value "<<i<<":";cin>>arr[i];

}

//To Find the Maximum and the Minimum Values.

  int j,k,value;

//Using array to find the max and the min values

 for(j=0;j<10;j++)
  for(k=9;k>j;k--)
     if(arr[k]<arr[k-1]) {
         int value=arr[k];
         arr[k]=arr[k-1];
         arr[k-1]=value;
}

  cout<<"Max="<<arr[9]<<"\nMin="<<arr[0];
  cout<<"\n";

 for(j=0;j<2;j++)
   for(k=0;k<10;k++)mode[k][j]=0;
     mode[0][0]=1;

//This part of the program is finding the Mode
 for(j=0;j<10;j++)
  for(k=0;k<10;k++)
   if(arr[j]==arr[k+1]) {++mode[j][0];mode[j][1]=arr[j];}

//This is to find Maximum Occurring Values
int max;
int l=0;
max=mode[0][0];
   for(k=0;k<10;k++)
    if(max<mode[k][0]){max=mode[k][0];l=k;}

//Printing the Results

  cout<<"The most occurring item:"<<mode[l][1]<<"\n";
  cout<<"It occurs "<<max<<" times.";
  cout<<"\n";
  system("PAUSE");

    return EXIT_SUCCESS;
}
